document.addEventListener("DOMContentLoaded", function () {
    const puzzleContainer = document.getElementById("puzzle-container");
    const playButton = document.getElementById("play-button");
    const successPopup = document.getElementById("success-popup");
    const closePopup = document.getElementById("close-popup");
    const imageSrc = document.getElementById("puzzle-image").src;
    let pieces = [];

    function createPuzzle() {
        puzzleContainer.innerHTML = "";
        pieces = [];

        for (let i = 0; i < 9; i++) {
            const piece = document.createElement("div");
            piece.classList.add("piece");
            piece.style.backgroundImage = `url('${imageSrc}')`;
            piece.style.backgroundPosition = `-${(i % 3) * 200}px -${Math.floor(i / 3) * 200}px`;
            piece.dataset.index = i;
            piece.draggable = true;
            pieces.push(piece);
        }

        pieces.forEach((piece) => {
            puzzleContainer.appendChild(piece);
        });

        addDragAndDrop();
    }

    function shufflePuzzle() {
        let shuffled = pieces.sort(() => Math.random() - 0.5);
        shuffled.forEach(piece => puzzleContainer.appendChild(piece));
    }

    function addDragAndDrop() {
        let draggedPiece = null;

        pieces.forEach(piece => {
            piece.addEventListener("dragstart", function () {
                draggedPiece = this;
                this.classList.add("dragging");
            });

            piece.addEventListener("dragend", function () {
                draggedPiece = null;
                this.classList.remove("dragging");
            });

            piece.addEventListener("dragover", function (e) {
                e.preventDefault();
            });

            piece.addEventListener("drop", function () {
                if (draggedPiece && draggedPiece !== this) {
                    let temp = this.style.backgroundPosition;
                    let tempIndex = this.dataset.index;
                    
                    this.style.backgroundPosition = draggedPiece.style.backgroundPosition;
                    this.dataset.index = draggedPiece.dataset.index;
                    
                    draggedPiece.style.backgroundPosition = temp;
                    draggedPiece.dataset.index = tempIndex;

                    checkIfSolved();
                }
            });
        });
    }

    function checkIfSolved() {
        let isSolved = pieces.every((piece, index) => piece.dataset.index == index);
        if (isSolved) {
            successPopup.style.display = "block"; // Show popup
            playButton.style.display = "block";  // Show play button again
        }
    }

    playButton.addEventListener("click", function () {
        createPuzzle();
        shufflePuzzle();
        successPopup.style.display = "none"; // Hide popup when game restarts
        playButton.style.display = "none";   // Hide play button
    });

    closePopup.addEventListener("click", function () {
        successPopup.style.display = "none"; // Close popup when clicking OK
    });

    createPuzzle(); // Initialize puzzle
});
