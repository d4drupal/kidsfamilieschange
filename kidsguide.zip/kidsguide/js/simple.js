document.addEventListener('DOMContentLoaded', function () {
    const videoThumbnails = document.querySelectorAll('.video-wrapper .video-thumbnail');
    if (videoThumbnails.length > 0) {
        videoThumbnails.forEach((thumbnail) => {
            thumbnail.addEventListener('click', function (e) {
                e.stopPropagation(); // Prevent triggering parent click event

                const parentItem = thumbnail.closest('.views-view-responsive-grid__item-inner');
                const videoContent = parentItem.querySelector('.vimeo-video-content');
                videoContent.classList.add('active');

                // Playing the video
                const iframe = videoContent.querySelector('iframe');
                const player = new Vimeo.Player(iframe);

                if (navigator.userAgent.includes("Chrome")) {
                    player.setMuted(true);
                }
                player.play().catch(error => {
                    console.log('Error playing video:', error);
                });

                // Function to close video
                function closeVideoPlayer() {
                    player.pause();
                    videoContent.classList.remove('active');
                    closeBtn.remove();
                }

                // Creating a Close Button
                const closeBtn = document.createElement('button');
                closeBtn.classList.add('custom-close-btn', 'btn-close', 'btn-close-white');
                closeBtn.addEventListener('click', function () {
                    closeVideoPlayer();
                });

                // Append Close button
                const videoEmbedContainer = videoContent.querySelector('.embed-container');
                if (videoEmbedContainer != null) {
                    videoEmbedContainer.insertBefore(closeBtn, videoEmbedContainer.firstChild);
                }

                // Close video when clicking outside
                videoContent.addEventListener('click', function (event) {
                    if (!closeBtn.contains(event.target) && event.target !== iframe) {
                        event.stopPropagation();
                        closeVideoPlayer();
                    }
                });
            });
        });
    }    

    document.querySelectorAll('.tips-list-card').forEach(tips => {
        const tipsDetails = tips.nextElementSibling;
        const audio = tipsDetails.querySelector('audio');
        const closeButton = tipsDetails.querySelector('.close-button');

        // Preload the background image
        const bgImageUrl = tipsDetails.style.backgroundImage.replace(/url\(['"]?(.*?)['"]?\)/, '$1');
        if (bgImageUrl) {
            const img = new Image();
            img.src = bgImageUrl;
        }

        const toggleTips = event => {
            event.stopPropagation();
            tipsDetails.classList.toggle('active');
            if (audio) {
                audio.pause();
                audio.currentTime = 0;
                audio.load();
                audio.play();
            }
        };

        const closeTips = event => {
            event.stopPropagation();
            tipsDetails.classList.remove('active');
            if (audio && !audio.paused) audio.pause();
        };

        tips.addEventListener('click', toggleTips);
        closeButton.addEventListener('click', closeTips);

        document.addEventListener('click', event => {
            if (!tips.contains(event.target) && !tipsDetails.contains(event.target)) {
                closeTips(event);
            }
        });
    });


    // Go back to the referring page
    const backButton = document.querySelector(".back-button");
    const referrer = document.referrer;
    
    if (backButton) {
      backButton.addEventListener("click", function (event) {
        event.preventDefault();
    
        if (referrer && new URL(referrer).origin === window.location.origin) {
          window.location.href = referrer; 
        }
      });
    }

})

jQuery(document).ready(function ($) {
    const body = $('body');

    const tipsPaths = [
        'path-dealing-with-change-tips',
        'path-family-friends-community-tips',
        'path-feelings-tips',
        'path-when-things-are-tough-tips',
        'path-your-rights-tips'
    ];

    const activitiesPaths = [
        'path-dealing-change-activities',
        'path-family-friends-community-activities',
        'path-feelings-activities',
        'path-when-things-are-tough-activities',
        'path-your-rights-activities'
    ];

    if (tipsPaths.some(cls => body.hasClass(cls))) {
        body.addClass('page-node-type-bg-tips');
    } else if (activitiesPaths.some(cls => body.hasClass(cls))) {
        body.addClass('page-node-type-bg-activities');
    }

    //Audio play/pause functionality on Activity detail page
    jQuery('.activity-item .Play').on('click', function() { 
        var $this = jQuery(this);
        var $audio = $this.closest('.activity-item').find('audio.audio')[0]; 
    
        if ($audio.paused) {
          $audio.play();
          $this.addClass('pause');
        } else {
          $audio.pause();
          $this.removeClass('pause');
        }
    });

    // Add the language as a class to <body>
    var lang = $("html").attr("lang");
    if (lang) {
        $("body").addClass(lang); 
    }
    
});


//Active class for menu to be highlighted where is the page
document.addEventListener("DOMContentLoaded", function () {
    const classToMenuIndex = {
      "dealing-change": 0,                 
      "family-friends-community": 1,      
      "feelings": 2,                      
      "when-things-are-tough": 3,         
      "your-rights": 4                    
    };
  
    const block = document.getElementById("block-kidsguide-content");
  
    for (const className in classToMenuIndex) {
      const menuIndex = classToMenuIndex[className];
  
      const bodyHasClass = document.body.classList.contains(className);
      const blockHasClass = block && block.querySelector(`.${className}`);
  
      if (bodyHasClass || blockHasClass) {
        const menuLinks = document.querySelectorAll("#superfish-main > li > a");
        if (menuLinks[menuIndex]) {
          menuLinks[menuIndex].classList.add("is-active");
        }
      }
    }
  });
  