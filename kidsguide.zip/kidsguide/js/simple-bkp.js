document.addEventListener('DOMContentLoaded', function () {
    const videoPaths = [
        '/dealing-change-videos',
        '/family-friends-community-videos',
        '/amis-famille-communauté-vidéo',
        '/feelings-videos',
        '/when-things-are-tough-videos',
        '/your-rights-videos'
    ];
    
    if (videoPaths.some(path => this.location.pathname.includes(path))) {
        const videoThumbnails = document.querySelectorAll('.video-wrapper .video-thumbnail');
        if (videoThumbnails.length > 0) {
            videoThumbnails.forEach((thumbnail) => {
                thumbnail.addEventListener('click', function (e) {
                    const parentItem = thumbnail.closest('.views-view-responsive-grid__item-inner');
                    const videoContent = parentItem.querySelector('.vimeo-video-content');
                    videoContent.classList.add('active');
    
                    // Playing the video
                    const iframe = videoContent.querySelector('iframe');
                    const player = new Vimeo.Player(iframe);
    
                    // Mute the video on autoplay in Google Chrome
                    if (navigator.userAgent.includes("Chrome")) {
                        player.setMuted(false);
                    }
                    player.play().catch(error => {
                        console.log('Error playing video:', error);
                    });
    
                    // Function to close video
                    function closeVideoPlayer() {
                        player.pause();
                        videoContent.classList.remove('active');
                        closeBtn.remove();
                    }
    
                    // Creating a Close Button
                    const closeBtn = document.createElement('button');
                    closeBtn.classList.add('custom-close-btn', 'btn-close', 'btn-close-white');
                    closeBtn.addEventListener('click', function () {
                        closeVideoPlayer();
                    });
    
                    // Append Close button
                    const videoEmbedContainer = videoContent.querySelector('.embed-container');
                    if (videoEmbedContainer != null) {
                        videoEmbedContainer.insertBefore(closeBtn, videoEmbedContainer.firstChild);
                    }
    
                    // Close video when clicking outside
                    videoContent.addEventListener('click', function (event) {
                        if (!closeBtn.contains(event.target) && event.target !== iframe) {
                            event.stopPropagation();
                            closeVideoPlayer();
                        }
                    });
                });
            });
        }
    }    


    document.querySelectorAll('.tips-list-card').forEach(tips => {
        const tipsDetails = tips.nextElementSibling;
        const audio = tipsDetails.querySelector('audio');
        const closeButton = tipsDetails.querySelector('.close-button');

        // Preload the background image
        const bgImageUrl = tipsDetails.style.backgroundImage.replace(/url\(['"]?(.*?)['"]?\)/, '$1');
        if (bgImageUrl) {
            const img = new Image();
            img.src = bgImageUrl;
        }

        const toggleTips = event => {
            event.stopPropagation();
            tipsDetails.classList.toggle('active');
            if (audio) {
                audio.pause();
                audio.currentTime = 0;
                audio.load();
                audio.play();
            }
        };

        const closeTips = event => {
            event.stopPropagation();
            tipsDetails.classList.remove('active');
            if (audio && !audio.paused) audio.pause();
        };

        tips.addEventListener('click', toggleTips);
        closeButton.addEventListener('click', closeTips);

        document.addEventListener('click', event => {
            if (!tips.contains(event.target) && !tipsDetails.contains(event.target)) {
                closeTips(event);
            }
        });
    });

    const backButton = document.querySelector(".back-button");

    // Allowed previous pages
    const allowedPages = [
        "dealing-change-activities",
        "family-friends-community",
        "feelings",
        "when-things-are-tough",
        "your-rights"
    ];

    // Get the previous page URL
    const referrer = document.referrer;

    // Check if the referrer is in the allowed list
    let isAllowedPage = referrer && allowedPages.some(page => referrer.includes(page));

    if (backButton) {
        backButton.addEventListener("click", function (event) {
            event.preventDefault(); // Prevent default anchor action

            if (isAllowedPage) {
                window.history.back(); // Go back only if referrer is allowed
            }
        });
    }

})


function previewPDF(pdfUrl) {
    // Embed PDF without toolbar (Chrome only workaround)
    document.getElementById('pdf-preview').src = pdfUrl + "#toolbar=0";
    document.getElementById('download-pdf').href = pdfUrl;
}

jQuery(document).ready(function ($) {
    const body = $('body');

    if (body.hasClass('path-dealing-with-change-tips')) {
        body.addClass('page-node-type-bg-tips');
    } else if (body.hasClass('path-family-friends-community-tips')) {
        body.addClass('page-node-type-bg-tips');
    } else if (body.hasClass('path-feelings-tips')) {
        body.addClass('page-node-type-bg-tips');
    } else if (body.hasClass('path-when-things-are-tough-tips')) {
        body.addClass('page-node-type-bg-tips');
    } else if (body.hasClass('path-your-rights-tips')) {
        body.addClass('page-node-type-bg-tips');
    }
    else if (body.hasClass('path-dealing-change-activities')) {
        body.addClass('page-node-type-bg-activities');
    }
    else if (body.hasClass('path-family-friends-community-activities')) {
        body.addClass('page-node-type-bg-activities');
    }
    else if (body.hasClass('path-feelings-activities')) {
        body.addClass('page-node-type-bg-activities');
    }
    else if (body.hasClass('path-when-things-are-tough-activities')) {
        body.addClass('page-node-type-bg-activities');
    }
    else if (body.hasClass('path-your-rights-activities')) {
        body.addClass('page-node-type-bg-activities');
    }

    jQuery('.activity-item .Play').on('click', function() {
        var $this = jQuery(this);
        var $audio = $this.closest('.activity-item').find('audio.audio')[0];
    
    
        // Toggle play/pause
        if ($audio.paused) {
          $audio.play();
          $this.addClass('pause');
        } else {
          $audio.pause();
          $this.removeClass('pause');
        }
      });
    
});


jQuery(document).ready(function ($) {    
    var menuMappings = [
        {
            keywords: [
                "dealing-change", "dealing-change-videos", "dealing-change-activities", "dealing-with-change-tips"
            ],
            menuIndex: 1
        },
        {
            keywords: [
                "family-friends-community", "family-friends-community-videos", "family-friends-community-activities", "family-friends-community-tips",
                "amis-famille-communauté-vidéo"
            ],
            menuIndex: 2
        },
        {
            keywords: [
                "feelings", "feelings-videos", "feelings-activities", "feelings-tips"
            ],
            menuIndex: 3
        },
        {
            keywords: [
                "when-things-are-tough", "when-things-are-tough-videos", "when-things-are-tough-activities", "when-things-are-tough-tips"
            ],
            menuIndex: 4
        },
        {
            keywords: [
                "your-rights", "your-rights-videos", "your-rights-activities", "your-rights-tips"
            ],
            menuIndex: 5
        }
    ];

    // Decode the URL to match special characters like é
    var currentUrl = decodeURIComponent(window.location.href.toLowerCase());

    menuMappings.forEach(function (mapping) {
        mapping.keywords.forEach(function (keyword) {
            if (currentUrl.includes(keyword.toLowerCase())) {
                $(".sf-menu li.sf-depth-1:nth-child(" + mapping.menuIndex + ") a").addClass("is-active");
            }
        });
    });

    // Add the language as a class to <body>
    var lang = $("html").attr("lang");
    if (lang) {
        $("body").addClass(lang); 
    }
});
