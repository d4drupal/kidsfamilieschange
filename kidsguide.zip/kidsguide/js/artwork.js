jQuery(document).ready(function ($) {
    // Set active class to the first image and its Play-pause div
    var firstContainer = $('.default-image-with-coordinate').first();
    var firstImage = firstContainer.find('img');
    var firstPlayPause = firstContainer.find('.Play-pause');
    var firstIndex = $('.default-image-with-coordinate').index(firstContainer);

    firstImage.addClass('active');
    firstPlayPause.addClass('active pause').text('Pause');

    // Show the first popup
    var firstPopup = $('.popup-data-wrapper .popup-data-with-img-desc-audio').eq(firstIndex);
    firstPopup.show();

    // Auto-play the first audio if available
    var firstAudio = firstPopup.find('audio').get(0);
    if (firstAudio) {
        firstAudio.play();
    }

    // On image click
    $('.default-image-with-coordinate img').on('click', function (e) {
        e.stopPropagation();

        var index = $('.default-image-with-coordinate img').index(this);

        // Pause all audio
        $('audio').each(function () {
            this.pause();
            this.currentTime = 0;
        });

        // Remove active class from all and reset Play-pause
        $('.default-image-with-coordinate img').removeClass('active');
        $('.Play-pause').removeClass('active pause').text('Play');

        // Set active on clicked image and its play-pause div
        $(this).addClass('active');
        $(this).siblings('.Play-pause').addClass('active pause').text('Pause');

        // Hide all popups
        $('.popup-data-wrapper .popup-data-with-img-desc-audio').hide();

        // Show corresponding popup
        var popupToShow = $('.popup-data-wrapper .popup-data-with-img-desc-audio').eq(index);
        popupToShow.show();

        // Play corresponding audio
        var audioToPlay = popupToShow.find('audio').get(0);
        if (audioToPlay) {
            audioToPlay.play();
        }
    });

    // On Play-pause button click
    $('.default-image-with-coordinate .Play-pause').on('click', function (e) {
        e.stopPropagation();

        var container = $(this).closest('.default-image-with-coordinate');
        var index = $('.default-image-with-coordinate').index(container);
        var popup = $('.popup-data-wrapper .popup-data-with-img-desc-audio').eq(index);
        var audio = popup.find('audio').get(0);

        if (audio) {
            if (audio.paused) {
                audio.play();
                $(this).text('Pause').addClass('pause').removeClass('play');
            } else {
                audio.pause();
                $(this).text('Play').removeClass('pause').addClass('play');
            }
        }
    });

    // Prevent closing when clicking inside popup
    $('.popup-data-with-img-desc-audio').on('click', function (e) {
        e.stopPropagation();
    });
});
