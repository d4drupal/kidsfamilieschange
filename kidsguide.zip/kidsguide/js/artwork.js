jQuery(document).ready(function ($) {
    // Set active class to the first image and its Play-pause div
    var firstContainer = $('.default-image-with-coordinate').first();
    var firstImage = firstContainer.find('img');
    var firstPlayPause = firstContainer.find('.Play-pause');

    firstImage.addClass('active');
    firstPlayPause.addClass('active').text('Pause').addClass('pause');

    // Show the first popup
    var firstPopup = firstImage.closest('.paragraph').find('.popup-data-with-img-desc-audio');
    firstPopup.show();

    // Auto-play the first audio if available
    var firstAudio = firstPopup.find('audio').get(0);
    if (firstAudio) {
        firstAudio.play();
    }

    // On image click
    $('.default-image-with-coordinate img').on('click', function (e) {
        e.stopPropagation();

        // Pause all audio
        $('audio').each(function () {
            this.pause();
            this.currentTime = 0;
        });

        // Remove active class and reset Play-pause text and pause class
        $('.default-image-with-coordinate img').removeClass('active');
        $('.default-image-with-coordinate .Play-pause')
            .removeClass('active pause')
            .text('Play');

        // Add active class to clicked image and its Play-pause div
        $(this).addClass('active');
        $(this).siblings('.Play-pause').addClass('active').text('Pause').addClass('pause');

        // Hide all popups
        $('.popup-data-with-img-desc-audio').hide();
        $('.default-image-with-coordinate img').removeClass('d-none');

        // Show popup for clicked image
        var parentParagraph = $(this).closest('.paragraph');
        var popupData = parentParagraph.find('.popup-data-with-img-desc-audio');
        popupData.show();

        // Play audio for clicked image if exists
        var audioElement = popupData.find('audio').get(0);
        if (audioElement) {
            audioElement.play();
        }
    });

    // Play-pause button click
    $('.default-image-with-coordinate .Play-pause').on('click', function (e) {
        e.stopPropagation();
    
        var container = $(this).closest('.default-image-with-coordinate');
        var popup = container.closest('.paragraph').find('.popup-data-with-img-desc-audio');
        var audio = popup.find('audio').get(0);
    
        if (audio) {
            if (audio.paused) {
                audio.play();
                $(this).text('Pause')
                    .addClass('pause')
                    .removeClass('play'); // ✅ Remove play class when starting
            } else {
                audio.pause();
                $(this).text('Play')
                    .removeClass('pause')
                    .addClass('play'); // ✅ Add play class when paused
            }
        }
    });

    // Prevent closing when clicking inside popup
    $('.popup-data-with-img-desc-audio').on('click', function (e) {
        e.stopPropagation();
    });
});
